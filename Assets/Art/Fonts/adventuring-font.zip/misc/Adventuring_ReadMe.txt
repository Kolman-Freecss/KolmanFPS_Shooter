
=== ADVENTURING ===

Keith Bates / K-Type © 2010 (version 1.01)
www.k-type.com    -    info@k-type.com

Rock-steady and friendly, yet animated and exciting, Adventuring evolved from the hand drawn, uppercase title lettering used for the 1950s and 1960s dust jackets of Enid Blyton's Famous Five books.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------